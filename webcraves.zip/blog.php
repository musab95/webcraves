<?php
include "header.html";
?>
    
    <section class="row blog_content">
        <div class="container">
            <div class="row">
                <div class="col-sm-8 blogs">
                    <div class="row m0 blog">
                        <div class="row m0 image"><a href="single.html"><img src="images/posts/blog/1.jpg" alt=""></a></div>
                        <ul class="blog_infos nav">
                            <li><a href="blog.html#"><i class="fa fa-calendar"></i>19 May, 2015</a></li>
                            <li><a href="blog.html#"><i class="fa fa-comment"></i>(3) comments</a></li>
                        </ul>
                        <h3><a href="single.html">image post for vps hosting</a></h3>
                        <p>Lorem ipsums dolor sit amet consectetur adipiscing elit integer lacinia malesuada justo vestibulum orci tristique non nunc nonc ultricies enim ut accumsan dolor nullam dapibus rhonus vehicula sed  diam porta tellus nec lacinia lacus vivamus placerat elit.</p>
                        <a href="single.html" class="btn btn-primary">read more</a>
                    </div>
                    <hr class="blog_bottom_line">
                    <div class="row m0 blog">
                        <div class="row m0 image">
                            <div id="gallery-post" class="carousel slide" data-ride="carousel">
                                <!-- Wrapper for slides -->
                                <div class="carousel-inner" role="listbox">
                                    <div class="item active">
                                        <img src="images/posts/blog/2.jpg" alt="...">
                                    </div>
                                    <div class="item">
                                        <img src="images/posts/blog/4.jpg" alt="...">
                                    </div>
                                </div>

                                <!-- Controls -->
                                <a class="left carousel-control" href="blog.html#gallery-post" role="button" data-slide="prev">
                                    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                                    <span class="sr-only">Previous</span>
                                </a>
                                <a class="right carousel-control" href="blog.html#gallery-post" role="button" data-slide="next">
                                    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                                    <span class="sr-only">Next</span>
                                </a>
                            </div>
                        </div>
                        <ul class="blog_infos nav">
                            <li><a href="blog.html#"><i class="fa fa-calendar"></i>19 May, 2015</a></li>
                            <li><a href="blog.html#"><i class="fa fa-comment"></i>(3) comments</a></li>
                        </ul>
                        <h3><a href="single.html">gallery post for vps hosting</a></h3>
                        <p>Lorem ipsums dolor sit amet consectetur adipiscing elit integer lacinia malesuada justo vestibulum orci tristique non nunc nonc ultricies enim ut accumsan dolor nullam dapibus rhonus vehicula sed  diam porta tellus nec lacinia lacus vivamus placerat elit.</p>
                        <a href="single.html" class="btn btn-primary">read more</a>
                    </div>
                    <hr class="blog_bottom_line">
                    <div class="row m0 blog">
                        <div class="row m0 image"><a href="single.html"><img src="images/posts/blog/1.jpg" alt=""><i class="fa fa-youtube-play"></i></a></div>
                        <ul class="blog_infos nav">
                            <li><a href="blog.html#"><i class="fa fa-calendar"></i>19 May, 2015</a></li>
                            <li><a href="blog.html#"><i class="fa fa-comment"></i>(3) comments</a></li>
                        </ul>
                        <h3><a href="single.html">video post for vps hosting</a></h3>
                        <p>Lorem ipsums dolor sit amet consectetur adipiscing elit integer lacinia malesuada justo vestibulum orci tristique non nunc nonc ultricies enim ut accumsan dolor nullam dapibus rhonus vehicula sed  diam porta tellus nec lacinia lacus vivamus placerat elit.</p>
                        <a href="single.html" class="btn btn-primary">read more</a>
                    </div>
                    <hr class="blog_bottom_line">
                    <div class="row m0 blog quote_blog">
                        <div class="media">
                            <div class="media-left"><i class="fa fa-quote-left"></i></div>
                            <div class="media-body">
                                <p>Donec tristique non neque id eleifend etiamed non eseport ultrices risus nunc laoreet turpis non eleifend felis tortor quis di praesent feugiat nam orci quam tempus vitae erat turpis at.</p>
                                <div class="row m0 quote_writer">- David Hemley</div>
                            </div>
                        </div>
                    </div>
                    <hr class="blog_bottom_line">
                    <div class="row m0 blog">
                        <div class="row m0 image"><a href="single.html"><img src="images/posts/blog/1.jpg" alt=""><i class="fa fa-volume-up"></i></a></div>
                        <ul class="blog_infos nav">
                            <li><a href="blog.html#"><i class="fa fa-calendar"></i>19 May, 2015</a></li>
                            <li><a href="blog.html#"><i class="fa fa-comment"></i>(3) comments</a></li>
                        </ul>
                        <h3><a href="single.html">audio post for vps hosting</a></h3>
                        <p>Lorem ipsums dolor sit amet consectetur adipiscing elit integer lacinia malesuada justo vestibulum orci tristique non nunc nonc ultricies enim ut accumsan dolor nullam dapibus rhonus vehicula sed  diam porta tellus nec lacinia lacus vivamus placerat elit.</p>
                        <a href="single.html" class="btn btn-primary">read more</a>
                    </div>
                    <hr class="blog_bottom_line">
                    
                    <nav class="pagination_nav">
                        <ul class="pagination">
                            <li><a href="blog.html#" aria-label="Previous">previous</a></li>
                            <li><a href="blog.html#">1</a></li>
                            <li><a href="blog.html#">2</a></li>
                            <li><a href="blog.html#">3</a></li>
                            <li><a href="blog.html#" aria-label="Next">next</a></li>
                        </ul>
                    </nav>
                </div>
                <div class="col-sm-4 sidebar">
                    <div class="row m0 inner">
                        <form action="blog.html#" class="row m0 search_form">
                            <h4>search</h4>
                            <div class="input-group">
                                <input type="search" class="form-control" placeholder="Search">
                                <span class="input-group-addon"><button type="submit"><i class="fa fa-search"></i></button></span>
                            </div>
                        </form>
                        <hr class="sidebar_line">
                        <div class="row m0 recent_posts">
                            <h4>recent posts</h4>
                            <div class="post media">
                                <div class="media-left">
                                    <a href="single.html"><img src="images/posts/recent/1.jpg" alt=""></a>
                                </div>
                                <div class="media-body">
                                    <h5><a href="single.html">Lorem ipsums dolor sit amet consectetu</a></h5>
                                    <div class="row m0 date"><i class="fa fa-calendar"></i>19 may, 2015</div>
                                </div>
                            </div>
                            <div class="post media">
                                <div class="media-left">
                                    <a href="single.html"><img src="images/posts/recent/2.jpg" alt=""></a>
                                </div>
                                <div class="media-body">
                                    <h5><a href="single.html">Lorem ipsums dolor sit amet consectetu</a></h5>
                                    <div class="row m0 date"><i class="fa fa-calendar"></i>19 may, 2015</div>
                                </div>
                            </div>
                            <div class="post media">
                                <div class="media-left">
                                    <a href="single.html"><img src="images/posts/recent/3.jpg" alt=""></a>
                                </div>
                                <div class="media-body">
                                    <h5><a href="single.html">Lorem ipsums dolor sit amet consectetu</a></h5>
                                    <div class="row m0 date"><i class="fa fa-calendar"></i>19 may, 2015</div>
                                </div>
                            </div>
                        </div>
                        <hr class="sidebar_line">
                        <div class="row m0 categories">
                            <h4>categories</h4>
                            <ul class="nav categories_list">
                                <li><a href="blog.html#">Free data analysis <span>(11)</span></a></li>
                                <li><a href="blog.html#">Security <span>(16)</span></a></li>
                                <li><a href="blog.html#">Free domain transfer <span>(19)</span></a></li>
                                <li><a href="blog.html#">Free data analysis <span>(22)</span></a></li>
                                <li><a href="blog.html#">Technical support <span>(25)</span></a></li>
                                <li><a href="blog.html#">Free web optimization <span>(31)</span></a></li>
                            </ul>
                        </div>
                        <hr class="sidebar_line">
                        <div class="row m0 archives">
                            <h4>archives</h4>
                            <ul class="nav archives_list">
                                <li><a href="blog.html#">January <span>(11)</span></a></li>
                                <li><a href="blog.html#">February <span>(16)</span></a></li>
                                <li><a href="blog.html#">March <span>(19)</span></a></li>
                                <li><a href="blog.html#">April <span>(22)</span></a></li>
                                <li><a href="blog.html#">May <span>(25)</span></a></li>
                            </ul>
                        </div>
                        <hr class="sidebar_line">
                        <div class="row m0 tags_row">
                            <h4>Tags</h4>
                            <a href="blog.html#" class="tag">Vestibul</a>
                            <a href="blog.html#" class="tag">Justo temp orci</a>
                            <a href="blog.html#" class="tag">Pellent</a>
                            <a href="blog.html#" class="tag">Namc</a>
                            <a href="blog.html#" class="tag">Consequat elit</a>
                            <a href="blog.html#" class="tag">Vestibulum act</a>
                            <a href="blog.html#" class="tag">Consequat donctum</a>
                            <a href="blog.html#" class="tag">Elit</a>
                            <a href="blog.html#" class="tag">Molestie</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php 
include "footer.html";
?>